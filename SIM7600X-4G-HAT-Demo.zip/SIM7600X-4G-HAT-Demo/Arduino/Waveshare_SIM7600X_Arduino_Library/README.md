# Waveshare SIM7600X Library for Arduino

This library provides the SIM7600X serial products API function

#Work for Waveshare SIM7600X 4G HAT modules:
SIM7600CE 4G HAT：http://www.waveshare.net/wiki/SIM7600CE_4G_HAT
SIM7600E-T 4G HAT：https://www.waveshare.com/wiki/SIM7600E-H_4G_HAT

Feature:4G 3G 2G GSM GPRS GNSS HAT for Raspberry Pi, LTE CAT4
You can connect this 4G module with computer to surf the Internet, or attach it onto Raspberry Pi to enable functions like 4G high speed connection, wireless communication, making telephone call, sending SMS, global positioning, etc.


---------------------------------------------------------
